// export function testScript() {
// 	alert(1233333);
// 	console.log("Hello from JavaScript!");
// }

// export function saveScore(score) {
// 	alert(score);
// 	alert(window.apiUrl);
// }

export class GameSessionManager {
    constructor(gameId) {
        this.gameId = gameId;
        this.sessionData = null;
        this.isActive = false;
        this.gameplayData = {
            score: 0,
            level: 1
        };
        this.startTime = null;
        this.token = new URLSearchParams(window.location.search).get('token') || localStorage.getItem('gameAuthToken');
    }
    
    /**
     * Bắt đầu phiên game mới
     */
    async startSession() {
        try {
			const token = new URLSearchParams(window.location.search).get('token') || localStorage.getItem('gameAuthToken');
			console.log(token);
            const response = await fetch(window.apiUrl + '/wp-json/game/v1/sessions/start', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Game-Auth-Token': token
                },
                body: JSON.stringify({
                    game_id: this.gameId
                })
            });
            
            if (!response.ok) {
                throw new Error('Failed to start game session');
            }
            
            this.sessionData = await response.json();
            this.isActive = true;
            this.startTime = new Date();
            
            // Khởi tạo dữ liệu gameplay cơ bản
            this.resetGameplayData();
            
            return true;
        } catch (error) {
            console.error('Error starting game session:', error);
            return false;
        }
    }
    
    /**
     * Khởi tạo lại dữ liệu gameplay
     */
    resetGameplayData() {
        this.gameplayData = {
            score: 0,
            level: 1
        };
    }
    
    /**
     * Cập nhật điểm số và level
     */
    updateScore(newScore, level) {
        this.gameplayData.score = newScore;
        if (level) {
            this.gameplayData.level = level;
        }
    }
    
    generateChecksum(data) {
        // Sắp xếp data theo key
        const sortedData = {};
        Object.keys(data).sort().forEach(key => {
            sortedData[key] = data[key];
        });
        
        // Tạo chuỗi từ data
        const dataString = JSON.stringify(sortedData);
        
        // Tạo HMAC với session token
        return this.createHmac(dataString, this.sessionData.session_token);
    }

    /**
     * Tạo HMAC với Web Crypto API
     */
    async createHmac(message, key) {
        const encoder = new TextEncoder();
        const keyData = encoder.encode(key);
        const messageData = encoder.encode(message);
        
        // Import key
        const cryptoKey = await crypto.subtle.importKey(
            'raw',
            keyData,
            { name: 'HMAC', hash: 'SHA-256' },
            false,
            ['sign']
        );
        
        // Sign data
        const signature = await crypto.subtle.sign(
            'HMAC',
            cryptoKey,
            messageData
        );
        
        // Convert to hex
        return Array.from(new Uint8Array(signature))
            .map(b => b.toString(16).padStart(2, '0'))
            .join('');
    }

    /**
     * Kết thúc phiên và gửi điểm
     */
    async endSession(finalScore, finalLevel) {
        if (!this.isActive || !this.sessionData) {
            console.error('No active session to end');
            return false;
        }
        
        const data = {
            session_id: this.sessionData.session_id,
            score: finalScore,
            level: finalLevel || this.gameplayData.level
        };
        
        // Tạo checksum
        const checksum = await this.generateChecksum(data);
        
        try {
            const response = await fetch(window.apiUrl + '/wp-json/game/v1/sessions/end', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Game-Auth-Token': this.token
                },
                body: JSON.stringify({
                    ...data,
                    checksum: checksum
                })
            });
            
        } catch (error) {
            console.error('Error ending game session:', error);
            return false;
        }
    }
}

let sessionManager;


export async function startGame() {
    const GAME_ID = 13;
    sessionManager = new GameSessionManager(GAME_ID);
    const sessionStarted = await sessionManager.startSession();
    
    if (!sessionStarted) {
        console.log("Không thể kết nối với server. Vui lòng thử lại!");
        return false;
    }
    
    return true;
}


export function updateGameProgress(score, level) {
    if (sessionManager) {
        sessionManager.updateScore(score, level);
    }
}


export async function endGame(finalScore, finalLevel) {
    if (!sessionManager) return;
    
    const result = await sessionManager.endSession(finalScore, finalLevel);
    
    // if (result && result.success) {
    //     showGameOverScreen(finalScore);
    // } else {
    //     showError("Không thể lưu điểm. Vui lòng thử lại!");
    // }
}


const scriptsInEvents = {

	async Gameevent_Event29_Act6(runtime, localVars)
	{
		console.log(runtime.globalVars.Level)
		if (runtime.globalVars.Level == 1) {
			startGame();
		}
	},

	async Gameevent_Event39_Act9(runtime, localVars)
	{
		updateGameProgress(runtime.globalVars.Score, runtime.globalVars.Level)
	},

	async Gameevent_Event40_Act9(runtime, localVars)
	{
		endGame(runtime.globalVars.Score);
	},

	async Gameevent_Event41_Act9(runtime, localVars)
	{
		endGame(runtime.globalVars.Score);
	},

	async Gameevent_Event42_Act16(runtime, localVars)
	{
		endGame(runtime.globalVars.Score);
	}
};

globalThis.C3.JavaScriptInEvents = scriptsInEvents;
