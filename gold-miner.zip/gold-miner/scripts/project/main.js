
// Import any other script files here, e.g.:
// import * as myModule from "./mymodule.js";
const production = true;
const apiUrl = '';



runOnStartup(async runtime =>
{
	// Code to run on the loading screen.
	// Note layouts, objects etc. are not yet available.
	
	runtime.addEventListener("beforeprojectstart", () => OnBeforeProjectStart(runtime));

	document.documentElement.requestFullscreen().then(() => {
		if (screen.orientation && screen.orientation.lock) {
			screen.orientation.lock("landscape").catch(function(error) {
				console.log("Failed to lock orientation: ", error);
			});
		}
	}).catch(function(error) {
		console.log("Failed to enter fullscreen: ", error);
	});
});

async function OnBeforeProjectStart(runtime)
{
	// Code to run just before 'On start of layout' on
	// the first layout. Loading has finished and initial
	// instances are created and available to use here.

	window.apiUrl = apiUrl;
	window.production = production;
	
	runtime.addEventListener("tick", () => Tick(runtime));
}

function Tick(runtime)
{
	// Code to run every tick
}

function checkGameAuth() {
    // Get token from localStorage
    const token = localStorage.getItem('gameAuthToken');
    
    if (!token) {
        // Redirect to WordPress login
        const currentUrl = encodeURIComponent(window.location.href);
        window.location.href = `${apiUrl}?redirect=${currentUrl}`;
        return;
    }
    
    // Verify token with WordPress
    fetch(`${apiUrl}/wp-json/game/v1/verify-auth`, {
        method: 'POST',
        headers: {
            'X-Game-Auth-Token': token
        }
    })
    .then(response => response.json())
    .then(data => {
		console.log(data);
        if (data.user_id) {
            // User is authenticated, start game
			window.currentUser = data;
        } else {
			console.log('invalid token');
            // Token invalid, redirect to login
            localStorage.removeItem('gameAuthToken');
            window.location.href = `${apiUrl}`;
        }
    })
    .catch(() => {
        // Error verifying token
        localStorage.removeItem('gameAuthToken');
        window.location.href = `${apiUrl}`;
		console.log('Error verifying token');
    });
}

function initGame() {
    // Check for token in URL
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    
    if (token) {
        // Save token and remove from URL
        localStorage.setItem('gameAuthToken', token);
        window.history.replaceState({}, document.title, window.location.pathname);
    }
    
    // Check auth before starting game
    checkGameAuth();
}

// Call initGame when your game loads
if (production) {
	window.addEventListener('load', initGame);
}


